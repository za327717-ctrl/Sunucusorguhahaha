import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import ComingSoonScreen from '@/screens/ComingSoonScreen';
import { getCommonScreenOptions } from '@/navigation/screenOptions';
import { useTheme } from '@/hooks/useTheme';

export type ComingSoonStackParamList = {
  ComingSoon: undefined;
};

const Stack = createNativeStackNavigator<ComingSoonStackParamList>();

export default function ComingSoonStackNavigator() {
  const { theme } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={getCommonScreenOptions({
        theme,
        isDark: theme.dark,
      })}
    >
      <Stack.Screen
        name="ComingSoon"
        component={ComingSoonScreen}
        options={{
          title: 'Yakında Gelecek',
        }}
      />
    </Stack.Navigator>
  );
}
