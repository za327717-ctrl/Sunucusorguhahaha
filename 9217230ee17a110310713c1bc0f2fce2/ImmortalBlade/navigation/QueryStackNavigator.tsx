import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import QueryScreen from "@/screens/QueryScreen";
import ServerDetailScreen from "@/screens/ServerDetailScreen";
import { getCommonScreenOptions } from "@/navigation/screenOptions";
import { HeaderTitle } from "@/components/HeaderTitle";

export type QueryStackParamList = {
  Query: undefined;
  ServerDetail: { ip: string; port: number };
};

const Stack = createNativeStackNavigator<QueryStackParamList>();

export default function QueryStackNavigator() {
  return (
    <Stack.Navigator screenOptions={getCommonScreenOptions}>
      <Stack.Screen
        name="Query"
        component={QueryScreen}
        options={{
          headerTitle: () => <HeaderTitle title="MC Sunucu Sorgula" />,
        }}
      />
      <Stack.Screen
        name="ServerDetail"
        component={ServerDetailScreen}
        options={{
          title: "Sunucu Detayları",
        }}
      />
    </Stack.Navigator>
  );
}
