import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import FavoritesScreen from "@/screens/FavoritesScreen";
import { getCommonScreenOptions } from "@/navigation/screenOptions";

export type FavoritesStackParamList = {
  Favorites: undefined;
};

const Stack = createNativeStackNavigator<FavoritesStackParamList>();

export default function FavoritesStackNavigator() {
  return (
    <Stack.Navigator screenOptions={getCommonScreenOptions}>
      <Stack.Screen
        name="Favorites"
        component={FavoritesScreen}
        options={{
          title: "Favori Sunucular",
        }}
      />
    </Stack.Navigator>
  );
}
