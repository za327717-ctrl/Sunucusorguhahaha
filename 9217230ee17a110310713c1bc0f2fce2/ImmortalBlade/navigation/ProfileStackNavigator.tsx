import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import ProfileScreen from "@/screens/ProfileScreen";
import BackupScreen from "@/screens/BackupScreen";
import PremiumScreen from "@/screens/PremiumScreen";
import AdminScreen from "@/screens/AdminScreen";
import { getCommonScreenOptions } from "@/navigation/screenOptions";

export type ProfileStackParamList = {
  Profile: undefined;
  Backup: undefined;
  Premium: undefined;
  Admin: undefined;
};

const Stack = createNativeStackNavigator<ProfileStackParamList>();

export default function ProfileStackNavigator() {
  return (
    <Stack.Navigator screenOptions={getCommonScreenOptions}>
      <Stack.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          title: "Profil",
        }}
      />
      <Stack.Screen
        name="Backup"
        component={BackupScreen}
        options={{
          title: "Yedeklemeler",
        }}
      />
      <Stack.Screen
        name="Premium"
        component={PremiumScreen}
        options={{
          title: "Premium Üyelik",
        }}
      />
      <Stack.Screen
        name="Admin"
        component={AdminScreen}
        options={{
          title: "Admin Paneli",
        }}
      />
    </Stack.Navigator>
  );
}
