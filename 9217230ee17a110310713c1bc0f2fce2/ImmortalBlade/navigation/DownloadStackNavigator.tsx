import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import DownloadScreen from '@/screens/DownloadScreen';
import { getCommonScreenOptions } from '@/navigation/screenOptions';
import { useTheme } from '@/hooks/useTheme';

export type DownloadStackParamList = {
  Download: undefined;
};

const Stack = createNativeStackNavigator<DownloadStackParamList>();

export default function DownloadStackNavigator() {
  const { theme } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={getCommonScreenOptions({
        theme,
        isDark: theme.dark,
      })}
    >
      <Stack.Screen
        name="Download"
        component={DownloadScreen}
        options={{
          title: 'İndirmeler',
        }}
      />
    </Stack.Navigator>
  );
}
