import * as BackgroundFetch from 'expo-background-fetch';
import * as TaskManager from 'expo-task-manager';
import { storage } from './storage';
import { queryServer } from './minecraftApi';
import { sendServerStatusNotification, sendPlayerCountNotification } from './notifications';

const BACKGROUND_FETCH_TASK = 'server-monitoring-task';

TaskManager.defineTask(BACKGROUND_FETCH_TASK, async () => {
  try {
    const settings = await storage.getSettings();
    
    if (!settings.notificationsEnabled) {
      return BackgroundFetch.BackgroundFetchResult.NoData;
    }

    const monitoredServers = await storage.getMonitoredServers();
    
    if (monitoredServers.length === 0) {
      return BackgroundFetch.BackgroundFetchResult.NoData;
    }

    let hasNewData = false;

    for (const monitored of monitoredServers) {
      const result = await queryServer(monitored.ip, monitored.port);
      
      if (!result.success || !result.server) {
        continue;
      }

      const server = result.server;
      const statusChanged = server.online !== monitored.lastStatus;
      const playerCountChanged = (server.players?.online || 0) !== monitored.lastPlayerCount;

      if (statusChanged && monitored.notifyOnStatusChange) {
        await sendServerStatusNotification(
          monitored.nickname || `${monitored.ip}:${monitored.port}`,
          server.online,
          monitored.ip,
          monitored.port
        );
        hasNewData = true;
      }

      if (playerCountChanged && monitored.notifyOnPlayerChange && server.online) {
        await sendPlayerCountNotification(
          monitored.nickname || `${monitored.ip}:${monitored.port}`,
          server.players?.online || 0,
          monitored.ip,
          monitored.port
        );
        hasNewData = true;
      }

      await storage.updateMonitoredServer(monitored.ip, monitored.port, {
        lastStatus: server.online,
        lastPlayerCount: server.players?.online || 0,
      });
    }

    return hasNewData 
      ? BackgroundFetch.BackgroundFetchResult.NewData 
      : BackgroundFetch.BackgroundFetchResult.NoData;
  } catch (error) {
    console.error('Background fetch error:', error);
    return BackgroundFetch.BackgroundFetchResult.Failed;
  }
});

export async function registerBackgroundFetch(intervalMinutes: number = 15) {
  try {
    const isRegistered = await TaskManager.isTaskRegisteredAsync(BACKGROUND_FETCH_TASK);
    
    if (isRegistered) {
      await BackgroundFetch.unregisterTaskAsync(BACKGROUND_FETCH_TASK);
    }

    await BackgroundFetch.registerTaskAsync(BACKGROUND_FETCH_TASK, {
      minimumInterval: intervalMinutes * 60,
      stopOnTerminate: false,
      startOnBoot: true,
    });

    console.log('Background fetch registered successfully');
  } catch (error) {
    console.error('Failed to register background fetch:', error);
  }
}

export async function unregisterBackgroundFetch() {
  try {
    await BackgroundFetch.unregisterTaskAsync(BACKGROUND_FETCH_TASK);
    console.log('Background fetch unregistered');
  } catch (error) {
    console.error('Failed to unregister background fetch:', error);
  }
}

export async function getBackgroundFetchStatus(): Promise<BackgroundFetch.BackgroundFetchStatus> {
  return await BackgroundFetch.getStatusAsync();
}
