import AsyncStorage from '@react-native-async-storage/async-storage';
import type { FavoriteServer, MinecraftServer, AppSettings, MonitoredServer } from '@/types/minecraft';

const FAVORITES_KEY = '@favorites';
const RECENT_KEY = '@recent';
const SETTINGS_KEY = '@settings';
const MONITORED_KEY = '@monitored';
const USER_KEY = '@user';
const BACKUPS_KEY = '@backups';

const defaultSettings: AppSettings = {
  displayName: 'Oyuncu',
  avatar: 'default',
  theme: 'system',
  defaultPort: 25565,
  scanTimeout: 10,
  notificationsEnabled: false,
  monitoringInterval: 5,
};

export const storage = {
  async getFavorites(): Promise<FavoriteServer[]> {
    try {
      const data = await AsyncStorage.getItem(FAVORITES_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading favorites:', error);
      return [];
    }
  },

  async saveFavorite(server: MinecraftServer): Promise<void> {
    try {
      const favorites = await this.getFavorites();
      const newFavorite: FavoriteServer = {
        ...server,
        id: `${server.ip}:${server.port}`,
        addedAt: Date.now(),
      };
      const updated = [...favorites, newFavorite];
      await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error saving favorite:', error);
      throw error;
    }
  },

  async removeFavorite(id: string): Promise<void> {
    try {
      const favorites = await this.getFavorites();
      const updated = favorites.filter(f => f.id !== id);
      await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error removing favorite:', error);
      throw error;
    }
  },

  async isFavorite(ip: string, port: number): Promise<boolean> {
    try {
      const favorites = await this.getFavorites();
      return favorites.some(f => f.ip === ip && f.port === port);
    } catch (error) {
      return false;
    }
  },

  async getRecent(): Promise<MinecraftServer[]> {
    try {
      const data = await AsyncStorage.getItem(RECENT_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading recent:', error);
      return [];
    }
  },

  async addRecent(server: MinecraftServer): Promise<void> {
    try {
      let recent = await this.getRecent();
      recent = recent.filter(s => !(s.ip === server.ip && s.port === server.port));
      recent.unshift(server);
      recent = recent.slice(0, 5);
      await AsyncStorage.setItem(RECENT_KEY, JSON.stringify(recent));
    } catch (error) {
      console.error('Error saving recent:', error);
    }
  },

  async clearRecent(): Promise<void> {
    try {
      await AsyncStorage.removeItem(RECENT_KEY);
    } catch (error) {
      console.error('Error clearing recent:', error);
    }
  },

  async getSettings(): Promise<AppSettings> {
    try {
      const data = await AsyncStorage.getItem(SETTINGS_KEY);
      return data ? { ...defaultSettings, ...JSON.parse(data) } : defaultSettings;
    } catch (error) {
      console.error('Error loading settings:', error);
      return defaultSettings;
    }
  },

  async saveSettings(settings: Partial<AppSettings>): Promise<void> {
    try {
      const current = await this.getSettings();
      const updated = { ...current, ...settings };
      await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error saving settings:', error);
      throw error;
    }
  },

  async getMonitoredServers(): Promise<MonitoredServer[]> {
    try {
      const data = await AsyncStorage.getItem(MONITORED_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading monitored servers:', error);
      return [];
    }
  },

  async addMonitoredServer(server: MinecraftServer, options: {
    notifyOnStatusChange?: boolean;
    notifyOnPlayerChange?: boolean;
  } = {}): Promise<void> {
    try {
      const monitored = await this.getMonitoredServers();
      const exists = monitored.find(m => m.ip === server.ip && m.port === server.port);
      
      if (exists) {
        return;
      }

      const newMonitored: MonitoredServer = {
        ip: server.ip,
        port: server.port,
        nickname: server.motd,
        lastStatus: server.online,
        lastPlayerCount: server.players?.online || 0,
        notifyOnStatusChange: options.notifyOnStatusChange ?? true,
        notifyOnPlayerChange: options.notifyOnPlayerChange ?? false,
        addedAt: Date.now(),
      };

      const updated = [...monitored, newMonitored];
      await AsyncStorage.setItem(MONITORED_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error adding monitored server:', error);
      throw error;
    }
  },

  async removeMonitoredServer(ip: string, port: number): Promise<void> {
    try {
      const monitored = await this.getMonitoredServers();
      const updated = monitored.filter(m => !(m.ip === ip && m.port === port));
      await AsyncStorage.setItem(MONITORED_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error removing monitored server:', error);
      throw error;
    }
  },

  async updateMonitoredServer(ip: string, port: number, updates: Partial<MonitoredServer>): Promise<void> {
    try {
      const monitored = await this.getMonitoredServers();
      const updated = monitored.map(m => 
        m.ip === ip && m.port === port ? { ...m, ...updates } : m
      );
      await AsyncStorage.setItem(MONITORED_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error updating monitored server:', error);
      throw error;
    }
  },

  async isMonitored(ip: string, port: number): Promise<boolean> {
    try {
      const monitored = await this.getMonitoredServers();
      return monitored.some(m => m.ip === ip && m.port === port);
    } catch (error) {
      return false;
    }
  },

  async saveUser(user: { username: string; email: string; password: string; createdAt: number }): Promise<void> {
    try {
      await AsyncStorage.setItem(USER_KEY, JSON.stringify(user));
    } catch (error) {
      console.error('Error saving user:', error);
      throw error;
    }
  },

  async getUser(): Promise<{ username: string; email: string; password: string; createdAt: number } | null> {
    try {
      const data = await AsyncStorage.getItem(USER_KEY);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Error loading user:', error);
      return null;
    }
  },

  async clearUser(): Promise<void> {
    try {
      await AsyncStorage.removeItem(USER_KEY);
    } catch (error) {
      console.error('Error clearing user:', error);
    }
  },

  async addBackup(backupData: {
    name: string;
    date: number;
    size: number;
    type: string;
  }): Promise<void> {
    try {
      const backups = await this.getBackups();
      backups.push(backupData);
      await AsyncStorage.setItem(BACKUPS_KEY, JSON.stringify(backups));
    } catch (error) {
      console.error('Error adding backup:', error);
      throw error;
    }
  },

  async getBackups(): Promise<Array<{
    name: string;
    date: number;
    size: number;
    type: string;
  }>> {
    try {
      const data = await AsyncStorage.getItem(BACKUPS_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading backups:', error);
      return [];
    }
  },

  async removeBackup(backupName: string): Promise<void> {
    try {
      const backups = await this.getBackups();
      const updated = backups.filter(b => b.name !== backupName);
      await AsyncStorage.setItem(BACKUPS_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error removing backup:', error);
      throw error;
    }
  },
};
