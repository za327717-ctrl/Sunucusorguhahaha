import type { MinecraftServer } from '@/types/minecraft';

export interface QueryResult {
  success: boolean;
  server?: MinecraftServer;
  error?: string;
}

export async function queryServer(ip: string, port: number, timeout: number = 10000): Promise<QueryResult> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    const startTime = Date.now();
    const response = await fetch(
      `https://api.mcsrvstat.us/3/${ip}:${port}`,
      { signal: controller.signal }
    );
    const endTime = Date.now();
    const ping = endTime - startTime;
    
    clearTimeout(timeoutId);

    if (!response.ok) {
      return {
        success: false,
        error: 'Sunucuya ulaşılamadı',
      };
    }

    const data = await response.json();

    if (!data.online) {
      return {
        success: true,
        server: {
          ip,
          port,
          online: false,
          lastQueried: Date.now(),
        },
      };
    }

    const motd = data.motd?.clean ? data.motd.clean.join(' ') : data.hostname || '';

    return {
      success: true,
      server: {
        ip,
        port,
        online: true,
        players: {
          online: data.players?.online || 0,
          max: data.players?.max || 0,
          list: data.players?.list || [],
        },
        version: data.version || 'Bilinmiyor',
        motd,
        icon: data.icon || undefined,
        ping,
        lastQueried: Date.now(),
      },
    };
  } catch (error: any) {
    if (error.name === 'AbortError') {
      return {
        success: false,
        error: 'Zaman aşımı',
      };
    }
    return {
      success: false,
      error: error.message || 'Bilinmeyen hata',
    };
  }
}

export async function scanPorts(
  ip: string, 
  startPort?: number, 
  endPort?: number
): Promise<QueryResult[]> {
  // Generate port range
  let ports: number[];
  if (startPort !== undefined && endPort !== undefined) {
    ports = [];
    for (let i = startPort; i <= endPort && i <= 65535; i++) {
      ports.push(i);
    }
  } else {
    // Default ports
    ports = [25565, 25566, 25567, 25568, 25569, 25570];
  }

  const results = await Promise.all(
    ports.map(port => queryServer(ip, port, 5000))
  );
  
  return results.filter(r => r.success && r.server?.online);
}
