import AsyncStorage from '@react-native-async-storage/async-storage';

const PREMIUM_KEY = '@premium';
const ADMIN_KEY = 'LxLo404Affetmezlan!';

export interface PremiumUser {
  isPremium: boolean;
  purchaseDate?: number;
  expiryDate?: number;
  purchaseId?: string;
}

export const premiumService = {
  async getPremiumStatus(): Promise<PremiumUser> {
    try {
      const data = await AsyncStorage.getItem(PREMIUM_KEY);
      return data ? JSON.parse(data) : { isPremium: false };
    } catch (error) {
      return { isPremium: false };
    }
  },

  async setPremium(purchaseId: string): Promise<void> {
    try {
      const premiumData: PremiumUser = {
        isPremium: true,
        purchaseDate: Date.now(),
        expiryDate: Date.now() + 365 * 24 * 60 * 60 * 1000, // 1 yıl
        purchaseId,
      };
      await AsyncStorage.setItem(PREMIUM_KEY, JSON.stringify(premiumData));
    } catch (error) {
      console.error('Error setting premium:', error);
    }
  },

  async verifyAdminKey(key: string): Promise<boolean> {
    return key === ADMIN_KEY;
  },

  async clearPremium(): Promise<void> {
    try {
      await AsyncStorage.removeItem(PREMIUM_KEY);
    } catch (error) {
      console.error('Error clearing premium:', error);
    }
  },
};
