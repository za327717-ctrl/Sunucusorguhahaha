import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export async function requestNotificationPermissions(): Promise<boolean> {
  if (!Device.isDevice) {
    return false;
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  return finalStatus === 'granted';
}

export async function schedulePushNotification(title: string, body: string, data?: any) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      data,
      sound: true,
    },
    trigger: null,
  });
}

export async function sendServerStatusNotification(
  serverName: string,
  isOnline: boolean,
  ip: string,
  port: number
) {
  const title = isOnline ? '🟢 Sunucu Çevrimiçi' : '🔴 Sunucu Çevrimdışı';
  const body = `${serverName} (${ip}:${port}) ${
    isOnline ? 'tekrar çevrimiçi!' : 'çevrimdışı oldu!'
  }`;

  await schedulePushNotification(title, body, { ip, port, online: isOnline });
}

export async function sendPlayerCountNotification(
  serverName: string,
  playerCount: number,
  ip: string,
  port: number
) {
  const title = '👥 Oyuncu Sayısı Değişti';
  const body = `${serverName}: ${playerCount} oyuncu çevrimiçi`;

  await schedulePushNotification(title, body, { ip, port, playerCount });
}
