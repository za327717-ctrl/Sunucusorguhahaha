export interface MinecraftServer {
  ip: string;
  port: number;
  online: boolean;
  ping?: number;
  players?: {
    online: number;
    max: number;
    list?: string[];
  };
  version?: string;
  motd?: string;
  icon?: string;
  lastQueried: number;
}

export interface FavoriteServer extends MinecraftServer {
  id: string;
  nickname?: string;
  addedAt: number;
}

export interface AppSettings {
  displayName: string;
  avatar: string;
  theme: 'light' | 'dark' | 'system';
  defaultPort: number;
  scanTimeout: number;
  notificationsEnabled: boolean;
  monitoringInterval: number;
}

export interface MonitoredServer {
  ip: string;
  port: number;
  nickname?: string;
  lastStatus: boolean;
  lastPlayerCount: number;
  notifyOnStatusChange: boolean;
  notifyOnPlayerChange: boolean;
  addedAt: number;
}
