import React, { useState } from 'react';
import { View, StyleSheet, TextInput, Alert, Pressable, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { storage } from '@/utils/storage';

interface AuthScreenProps {
  onLogin: (username: string) => void;
}

export default function AuthScreen({ onLogin }: AuthScreenProps) {
  const { theme } = useTheme();
  const [isSignUp, setIsSignUp] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSignUp = async () => {
    if (!username.trim()) {
      Alert.alert('Hata', 'Kullanıcı adını girin');
      return;
    }
    if (!email.trim()) {
      Alert.alert('Hata', 'E-posta adresini girin');
      return;
    }
    if (!validateEmail(email)) {
      Alert.alert('Hata', 'Geçerli bir e-posta adresi girin');
      return;
    }
    if (!password) {
      Alert.alert('Hata', 'Şifreyi girin');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Hata', 'Şifre en az 6 karakter olmalı');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('Hata', 'Şifreler eşleşmiyor');
      return;
    }

    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      await storage.saveUser({
        username,
        email,
        password,
        createdAt: Date.now(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onLogin(username);
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Hata', 'Kayıt başarısız. Lütfen tekrar deneyin.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    if (!username.trim()) {
      Alert.alert('Hata', 'Kullanıcı adını girin');
      return;
    }
    if (!password) {
      Alert.alert('Hata', 'Şifreyi girin');
      return;
    }

    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const user = await storage.getUser();
      if (user && user.username === username && user.password === password) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        onLogin(user.username);
      } else {
        throw new Error('Geçersiz kimlik bilgileri');
      }
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Hata', 'Giriş başarısız. Kimlik bilgilerinizi kontrol edin.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* Header */}
        <Card elevation={2}>
          <View style={styles.headerContent}>
            <Feather name="lock" size={40} color={theme.primary} />
            <ThemedText style={styles.title}>
              {isSignUp ? 'Yeni Hesap' : 'Giriş'}
            </ThemedText>
            <ThemedText style={styles.subtitle}>
              {isSignUp
                ? 'Sunucu yönetiminize başlamak için hesap açın'
                : 'Hesabınıza giriş yapın'}
            </ThemedText>
          </View>
        </Card>

        {/* Form */}
        <Card elevation={2} style={{ marginTop: Spacing.lg, marginBottom: Spacing.lg }}>
          {/* Username */}
          <View style={styles.inputContainer}>
            <ThemedText style={styles.label}>Kullanıcı Adı</ThemedText>
            <TextInput
              style={[
                styles.input,
                {
                  backgroundColor: theme.inputBackground,
                  borderColor: theme.inputBorder,
                  color: theme.text,
                },
              ]}
              placeholder="oyuncu"
              placeholderTextColor={theme.textSecondary}
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              autoCorrect={false}
              editable={!loading}
            />
          </View>

          {/* Email (SignUp only) */}
          {isSignUp && (
            <View style={styles.inputContainer}>
              <ThemedText style={styles.label}>E-posta Adresi</ThemedText>
              <TextInput
                style={[
                  styles.input,
                  {
                    backgroundColor: theme.inputBackground,
                    borderColor: theme.inputBorder,
                    color: theme.text,
                  },
                ]}
                placeholder="oyuncu@example.com"
                placeholderTextColor={theme.textSecondary}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                editable={!loading}
              />
            </View>
          )}

          {/* Password */}
          <View style={styles.inputContainer}>
            <ThemedText style={styles.label}>Şifre</ThemedText>
            <View style={[styles.passwordInputWrapper, { borderColor: theme.inputBorder, backgroundColor: theme.inputBackground }]}>
              <TextInput
                style={[
                  styles.passwordInput,
                  {
                    color: theme.text,
                  },
                ]}
                placeholder="••••••••"
                placeholderTextColor={theme.textSecondary}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                editable={!loading}
              />
              <Pressable onPress={() => setShowPassword(!showPassword)} style={styles.passwordToggle}>
                <Feather
                  name={showPassword ? 'eye-off' : 'eye'}
                  size={18}
                  color={theme.textSecondary}
                />
              </Pressable>
            </View>
          </View>

          {/* Confirm Password (SignUp only) */}
          {isSignUp && (
            <View style={styles.inputContainer}>
              <ThemedText style={styles.label}>Şifreyi Onayla</ThemedText>
              <View style={[styles.passwordInputWrapper, { borderColor: theme.inputBorder, backgroundColor: theme.inputBackground }]}>
                <TextInput
                  style={[
                    styles.passwordInput,
                    {
                      color: theme.text,
                    },
                  ]}
                  placeholder="••••••••"
                  placeholderTextColor={theme.textSecondary}
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  secureTextEntry={!showConfirmPassword}
                  editable={!loading}
                />
                <Pressable onPress={() => setShowConfirmPassword(!showConfirmPassword)} style={styles.passwordToggle}>
                  <Feather
                    name={showConfirmPassword ? 'eye-off' : 'eye'}
                    size={18}
                    color={theme.textSecondary}
                  />
                </Pressable>
              </View>
            </View>
          )}
        </Card>

        {/* Action Buttons */}
        <Button
          onPress={isSignUp ? handleSignUp : handleLogin}
          disabled={loading}
          style={{ backgroundColor: theme.primary, marginBottom: Spacing.md }}
        >
          <ThemedText style={{ color: '#fff', fontWeight: '600', fontSize: 16 }}>
            {isSignUp ? 'Hesap Aç' : 'Giriş Yap'}
          </ThemedText>
        </Button>

        {/* Toggle Auth Mode */}
        <Card elevation={2}>
          <View style={styles.toggleContainer}>
            <ThemedText style={styles.toggleText}>
              {isSignUp ? 'Zaten hesabınız var mı?' : 'Hesabınız yok mu?'}
            </ThemedText>
            <Button
              onPress={() => {
                setIsSignUp(!isSignUp);
                setUsername('');
                setEmail('');
                setPassword('');
                setConfirmPassword('');
              }}
              disabled={loading}
              style={{
                backgroundColor: 'transparent',
                borderWidth: 1,
                borderColor: theme.primary,
              }}
            >
              <ThemedText style={{ color: theme.primary, fontWeight: '600' }}>
                {isSignUp ? 'Giriş Yap' : 'Kayıt Ol'}
              </ThemedText>
            </Button>
          </View>
        </Card>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: Spacing.lg,
    paddingBottom: Spacing.xl,
    minHeight: '100%',
  },
  headerContent: {
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    marginTop: Spacing.md,
    marginBottom: Spacing.sm,
  },
  subtitle: {
    fontSize: 14,
    opacity: 0.7,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: Spacing.lg,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: Spacing.sm,
    opacity: 0.8,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.md,
    fontSize: 16,
  },
  passwordInputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingRight: Spacing.sm,
  },
  passwordInput: {
    flex: 1,
    height: 48,
    paddingHorizontal: Spacing.md,
    fontSize: 16,
  },
  passwordToggle: {
    padding: Spacing.sm,
  },
  toggleContainer: {
    alignItems: 'center',
    gap: Spacing.md,
  },
  toggleText: {
    fontSize: 14,
    opacity: 0.7,
  },
});
