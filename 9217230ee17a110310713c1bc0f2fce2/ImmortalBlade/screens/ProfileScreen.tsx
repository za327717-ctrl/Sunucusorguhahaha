import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TextInput, Image, Pressable, useColorScheme, Alert, Switch } from 'react-native';
import { ScreenScrollView } from '@/components/ScreenScrollView';
import { ThemedText } from '@/components/ThemedText';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import { storage } from '@/utils/storage';
import type { AppSettings } from '@/types/minecraft';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { requestNotificationPermissions } from '@/utils/notifications';
import { registerBackgroundFetch, unregisterBackgroundFetch } from '@/utils/backgroundMonitoring';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { ProfileStackParamList } from '@/navigation/ProfileStackNavigator';

type ProfileNavigationProp = NativeStackNavigationProp<ProfileStackParamList>;

export default function ProfileScreen() {
  const navigation = useNavigation<ProfileNavigationProp>();
  const { theme } = useTheme();
  const systemColorScheme = useColorScheme();
  const [settings, setSettings] = useState<AppSettings>({
    displayName: 'Oyuncu',
    avatar: 'default',
    theme: 'system',
    defaultPort: 25565,
    scanTimeout: 10,
    notificationsEnabled: false,
    monitoringInterval: 5,
  });
  const [hasNotificationPermission, setHasNotificationPermission] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const saved = await storage.getSettings();
    setSettings(saved);
  };

  const handleSave = async () => {
    try {
      await storage.saveSettings(settings);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Başarılı', 'Ayarlarınız kaydedildi');
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Hata', 'Ayarlar kaydedilemedi');
    }
  };

  const handleClearRecent = async () => {
    Alert.alert(
      'Geçmişi Temizle',
      'Son sorgulanan sunucuları temizlemek istediğinize emin misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Temizle',
          style: 'destructive',
          onPress: async () => {
            await storage.clearRecent();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
        },
      ]
    );
  };

  const handleRequestNotificationPermission = async () => {
    const granted = await requestNotificationPermissions();
    setHasNotificationPermission(granted);
    
    if (granted) {
      Alert.alert('Başarılı', 'Bildirim izni verildi');
    } else {
      Alert.alert('Hata', 'Bildirim izni reddedildi. Lütfen ayarlardan izin verin.');
    }
  };

  const handleToggleNotifications = async (value: boolean) => {
    if (value && !hasNotificationPermission) {
      const granted = await requestNotificationPermissions();
      if (!granted) {
        Alert.alert('Hata', 'Bildirim izni reddedildi. Lütfen ayarlardan izin verin.');
        return;
      }
      setHasNotificationPermission(true);
    }

    setSettings({ ...settings, notificationsEnabled: value });
    
    if (value) {
      await registerBackgroundFetch(settings.monitoringInterval);
    } else {
      await unregisterBackgroundFetch();
    }
  };

  return (
    <ScreenScrollView>
      <Card>
        <View style={styles.avatarSection}>
          <Image
            source={require('@/assets/images/default-avatar.png')}
            style={styles.avatar}
          />
          <ThemedText style={styles.avatarHint}>Minecraft Oyuncusu</ThemedText>
        </View>
      </Card>

      <Card style={{ marginTop: Spacing.lg }}>
        <ThemedText style={styles.sectionTitle}>Profil Bilgileri</ThemedText>
        
        <View style={styles.inputContainer}>
          <ThemedText style={styles.label}>Görünen İsim</ThemedText>
          <TextInput
            style={[styles.input, { 
              backgroundColor: theme.inputBackground, 
              borderColor: theme.inputBorder,
              color: theme.text 
            }]}
            value={settings.displayName}
            onChangeText={(text) => setSettings({ ...settings, displayName: text })}
            placeholder="Oyuncu"
            placeholderTextColor={theme.textSecondary}
          />
        </View>
      </Card>

      <Card style={{ marginTop: Spacing.lg }}>
        <ThemedText style={styles.sectionTitle}>Ayarlar</ThemedText>
        
        <View style={styles.inputContainer}>
          <ThemedText style={styles.label}>Varsayılan Port</ThemedText>
          <TextInput
            style={[styles.input, { 
              backgroundColor: theme.inputBackground, 
              borderColor: theme.inputBorder,
              color: theme.text 
            }]}
            value={settings.defaultPort.toString()}
            onChangeText={(text) => {
              const num = parseInt(text) || 25565;
              setSettings({ ...settings, defaultPort: num });
            }}
            placeholder="25565"
            placeholderTextColor={theme.textSecondary}
            keyboardType="number-pad"
          />
        </View>

        <View style={styles.inputContainer}>
          <ThemedText style={styles.label}>Tarama Zaman Aşımı (saniye)</ThemedText>
          <View style={styles.timeoutControl}>
            {[5, 10, 15].map((value) => (
              <Pressable
                key={value}
                onPress={() => {
                  setSettings({ ...settings, scanTimeout: value });
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }}
                style={[
                  styles.timeoutButton,
                  {
                    backgroundColor: settings.scanTimeout === value ? theme.primary : theme.backgroundDefault,
                    borderColor: settings.scanTimeout === value ? theme.primary : theme.border,
                  },
                ]}
              >
                <ThemedText
                  style={{
                    color: settings.scanTimeout === value ? '#fff' : theme.text,
                    fontWeight: '600',
                  }}
                >
                  {value}s
                </ThemedText>
              </Pressable>
            ))}
          </View>
        </View>

        <Button 
          onPress={handleSave}
          style={{ backgroundColor: theme.success, marginTop: Spacing.lg }}
        >
          <ThemedText style={{ color: '#fff', fontWeight: '600' }}>
            Kaydet
          </ThemedText>
        </Button>
      </Card>

      <Card style={{ marginTop: Spacing.lg }}>
        <ThemedText style={styles.sectionTitle}>Bildirimler</ThemedText>
        
        <View style={styles.settingRow}>
          <View style={styles.settingLabel}>
            <ThemedText style={styles.label}>Bildirimleri Etkinleştir</ThemedText>
            <ThemedText style={styles.description}>Sunucu durumu değişiklikleri hakkında bildir</ThemedText>
          </View>
          <Switch
            value={settings.notificationsEnabled}
            onValueChange={handleToggleNotifications}
            trackColor={{ false: theme.border, true: theme.primary }}
            thumbColor={settings.notificationsEnabled ? theme.success : theme.textSecondary}
          />
        </View>

        {settings.notificationsEnabled && (
          <>
            <View style={styles.settingRow}>
              <View style={styles.settingLabel}>
                <ThemedText style={styles.label}>İzleme Aralığı (dakika)</ThemedText>
                <ThemedText style={styles.description}>Sunucuları kontrol etme sıklığı</ThemedText>
              </View>
              <View style={styles.intervalControl}>
                {[5, 10, 15, 30].map((value) => (
                  <Pressable
                    key={value}
                    onPress={() => {
                      setSettings({ ...settings, monitoringInterval: value });
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    }}
                    style={[
                      styles.intervalButton,
                      {
                        backgroundColor: settings.monitoringInterval === value ? theme.primary : theme.backgroundDefault,
                        borderColor: settings.monitoringInterval === value ? theme.primary : theme.border,
                      },
                    ]}
                  >
                    <ThemedText
                      style={{
                        color: settings.monitoringInterval === value ? '#fff' : theme.text,
                        fontWeight: '600',
                        fontSize: 12,
                      }}
                    >
                      {value}
                    </ThemedText>
                  </Pressable>
                ))}
              </View>
            </View>

            <Button 
              onPress={handleSave}
              style={{ backgroundColor: theme.primary, marginTop: Spacing.lg }}
            >
              <ThemedText style={{ color: '#fff', fontWeight: '600' }}>
                Ayarları Kaydet
              </ThemedText>
            </Button>
          </>
        )}
      </Card>

      <Card style={{ marginTop: Spacing.lg }}>
        <ThemedText style={styles.sectionTitle}>Veri Yönetimi</ThemedText>
        
        <Button 
          onPress={handleClearRecent}
          style={{ 
            backgroundColor: 'transparent',
            borderWidth: 1,
            borderColor: theme.danger
          }}
        >
          <View style={styles.buttonContent}>
            <Feather name="trash-2" size={18} color={theme.danger} />
            <ThemedText style={{ color: theme.danger, fontWeight: '600', marginLeft: Spacing.sm }}>
              Geçmişi Temizle
            </ThemedText>
          </View>
        </Button>
      </Card>

      <Card style={{ marginTop: Spacing.lg }}>
        <ThemedText style={styles.sectionTitle}>Premium & İçerik</ThemedText>
        
        <Button 
          onPress={() => navigation.navigate('Premium')}
          style={{ 
            backgroundColor: theme.primary,
            marginBottom: Spacing.md 
          }}
        >
          <View style={styles.buttonContent}>
            <Feather name="gift" size={18} color="#fff" />
            <ThemedText style={{ color: '#fff', fontWeight: '600', marginLeft: Spacing.sm }}>
              Premium Üyelik
            </ThemedText>
          </View>
        </Button>

        <Button 
          onPress={() => navigation.navigate('Admin')}
          style={{ 
            backgroundColor: '#666',
          }}
        >
          <View style={styles.buttonContent}>
            <Feather name="shield" size={18} color="#fff" />
            <ThemedText style={{ color: '#fff', fontWeight: '600', marginLeft: Spacing.sm }}>
              Admin Paneli
            </ThemedText>
          </View>
        </Button>
      </Card>

      <Card style={{ marginTop: Spacing.lg }}>
        <ThemedText style={styles.sectionTitle}>Hakkında</ThemedText>
        
        <View style={styles.aboutRow}>
          <ThemedText style={styles.aboutLabel}>Versiyon</ThemedText>
          <ThemedText style={styles.aboutValue}>1.0.0</ThemedText>
        </View>
        
        <View style={styles.aboutRow}>
          <ThemedText style={styles.aboutLabel}>Uygulama</ThemedText>
          <ThemedText style={styles.aboutValue}>MC Sunucu Sorgula</ThemedText>
        </View>
      </Card>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  avatarSection: {
    alignItems: 'center',
    paddingVertical: Spacing.xl,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: Spacing.md,
  },
  avatarHint: {
    fontSize: 14,
    opacity: 0.6,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: Spacing.lg,
  },
  inputContainer: {
    marginBottom: Spacing.lg,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: Spacing.sm,
    opacity: 0.8,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.md,
    fontSize: 16,
  },
  timeoutControl: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  timeoutButton: {
    flex: 1,
    height: 48,
    borderRadius: BorderRadius.xs,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  aboutRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(128, 128, 128, 0.1)',
  },
  aboutLabel: {
    fontSize: 14,
    opacity: 0.6,
  },
  aboutValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.lg,
    paddingVertical: Spacing.md,
  },
  settingLabel: {
    flex: 1,
    marginRight: Spacing.md,
  },
  description: {
    fontSize: 12,
    opacity: 0.6,
    marginTop: Spacing.xs,
  },
  intervalControl: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  intervalButton: {
    width: 45,
    height: 40,
    borderRadius: BorderRadius.xs,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
