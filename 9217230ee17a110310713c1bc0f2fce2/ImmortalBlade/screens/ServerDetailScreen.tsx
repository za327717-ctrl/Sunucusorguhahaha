import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ActivityIndicator, FlatList, Image } from 'react-native';
import { ScreenScrollView } from '@/components/ScreenScrollView';
import { ThemedText } from '@/components/ThemedText';
import { Card } from '@/components/Card';
import { StatusBadge } from '@/components/StatusBadge';
import { PingIndicator } from '@/components/PingIndicator';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import { queryServer } from '@/utils/minecraftApi';
import type { MinecraftServer } from '@/types/minecraft';
import { Feather } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { QueryStackParamList } from '@/navigation/QueryStackNavigator';

type Props = NativeStackScreenProps<QueryStackParamList, 'ServerDetail'>;

export default function ServerDetailScreen({ route }: Props) {
  const { ip, port } = route.params;
  const { theme } = useTheme();
  const [loading, setLoading] = useState(true);
  const [server, setServer] = useState<MinecraftServer | null>(null);
  const [playerList, setPlayerList] = useState<string[]>([]);

  useEffect(() => {
    loadServerDetails();
  }, []);

  const loadServerDetails = async () => {
    setLoading(true);
    const result = await queryServer(ip, port);
    
    if (result.success && result.server) {
      setServer(result.server);
      if (result.server.online && result.server.players?.list) {
        setPlayerList(result.server.players.list);
      }
    }
    
    setLoading(false);
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.primary} />
        <ThemedText style={styles.loadingText}>Sunucu bilgileri yükleniyor...</ThemedText>
      </View>
    );
  }

  if (!server) {
    return (
      <View style={styles.errorContainer}>
        <Feather name="alert-circle" size={64} color={theme.danger} />
        <ThemedText style={styles.errorText}>Sunucu bilgileri yüklenemedi</ThemedText>
      </View>
    );
  }

  return (
    <ScreenScrollView>
      <Card>
        <View style={styles.header}>
          <Image
            source={
              server.icon
                ? { uri: server.icon }
                : require('@/assets/images/grass-block.png')
            }
            style={styles.icon}
          />
          <View style={styles.headerInfo}>
            <ThemedText style={styles.serverName} numberOfLines={2}>
              {server.motd || server.ip}
            </ThemedText>
            <ThemedText style={styles.serverAddress}>
              {server.ip}:{server.port}
            </ThemedText>
          </View>
        </View>

        <View style={styles.statusRow}>
          <StatusBadge online={server.online} />
          {server.online && server.ping !== undefined && (
            <PingIndicator ping={server.ping} />
          )}
        </View>

        {server.online && (
          <>
            <View style={styles.details}>
              <View style={styles.detailItem}>
                <Feather name="users" size={16} color={theme.textSecondary} />
                <ThemedText style={styles.detailText}>
                  {server.players?.online}/{server.players?.max} oyuncu
                </ThemedText>
              </View>
              {server.version && (
                <View style={styles.detailItem}>
                  <Feather name="package" size={16} color={theme.textSecondary} />
                  <ThemedText style={styles.detailText}>{server.version}</ThemedText>
                </View>
              )}
            </View>
          </>
        )}
      </Card>

      {server.online && playerList.length > 0 && (
        <Card style={{ marginTop: Spacing.lg }}>
          <ThemedText style={styles.sectionTitle}>
            Çevrimiçi Oyuncular ({playerList.length})
          </ThemedText>
          
          <View style={styles.playerList}>
            {playerList.map((player, index) => (
              <View key={index} style={[styles.playerItem, { borderBottomColor: theme.border }]}>
                <View style={styles.playerIcon}>
                  <Feather name="user" size={16} color={theme.primary} />
                </View>
                <ThemedText style={styles.playerName}>{player}</ThemedText>
              </View>
            ))}
          </View>
        </Card>
      )}

      {server.online && playerList.length === 0 && (
        <Card style={{ marginTop: Spacing.lg }}>
          <View style={styles.emptyPlayers}>
            <Feather name="users" size={48} color={theme.textSecondary} style={{ opacity: 0.3 }} />
            <ThemedText style={styles.emptyText}>
              Oyuncu listesi bilgisi mevcut değil
            </ThemedText>
            <ThemedText style={styles.emptySubtext}>
              Bazı sunucular oyuncu listesini gizler
            </ThemedText>
          </View>
        </Card>
      )}
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing['3xl'],
  },
  loadingText: {
    marginTop: Spacing.lg,
    fontSize: 16,
    opacity: 0.6,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing['3xl'],
  },
  errorText: {
    marginTop: Spacing.lg,
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  icon: {
    width: 64,
    height: 64,
    borderRadius: BorderRadius.xs,
    marginRight: Spacing.md,
  },
  headerInfo: {
    flex: 1,
  },
  serverName: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: Spacing.xs,
  },
  serverAddress: {
    fontSize: 14,
    opacity: 0.6,
    fontFamily: 'monospace',
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  details: {
    gap: Spacing.sm,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  detailText: {
    fontSize: 14,
    opacity: 0.8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: Spacing.md,
  },
  playerList: {
    gap: 0,
  },
  playerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  playerIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(92, 184, 92, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  playerName: {
    fontSize: 16,
    fontWeight: '500',
  },
  emptyPlayers: {
    alignItems: 'center',
    paddingVertical: Spacing['3xl'],
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: Spacing.lg,
    textAlign: 'center',
  },
  emptySubtext: {
    fontSize: 14,
    marginTop: Spacing.sm,
    opacity: 0.6,
    textAlign: 'center',
  },
});
