import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, RefreshControl, Alert } from 'react-native';
import { ThemedView } from '@/components/ThemedView';
import { ServerInfoCard } from '@/components/ServerInfoCard';
import { EmptyState } from '@/components/EmptyState';
import { useScreenInsets } from '@/hooks/useScreenInsets';
import { storage } from '@/utils/storage';
import { queryServer } from '@/utils/minecraftApi';
import type { FavoriteServer } from '@/types/minecraft';
import { Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { QueryStackParamList } from '@/navigation/QueryStackNavigator';

export default function FavoritesScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<QueryStackParamList>>();
  const insets = useScreenInsets();
  const { theme } = useTheme();
  const [favorites, setFavorites] = useState<FavoriteServer[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(
    React.useCallback(() => {
      loadFavorites();
    }, [])
  );

  const loadFavorites = async () => {
    const data = await storage.getFavorites();
    setFavorites(data);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    const updated = await Promise.all(
      favorites.map(async (fav) => {
        const result = await queryServer(fav.ip, fav.port, 5000);
        if (result.success && result.server) {
          return { ...fav, ...result.server };
        }
        return fav;
      })
    );

    setFavorites(updated);
    setRefreshing(false);
  };

  const handleRemove = async (id: string) => {
    Alert.alert(
      'Favorilerden Kaldır',
      'Bu sunucuyu favorilerden kaldırmak istediğinize emin misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Kaldır',
          style: 'destructive',
          onPress: async () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            await storage.removeFavorite(id);
            await loadFavorites();
          },
        },
      ]
    );
  };

  const handleServerPress = async (server: FavoriteServer) => {
    const index = favorites.findIndex(f => f.id === server.id);
    if (index !== -1) {
      const newFavorites = [...favorites];
      newFavorites[index] = { ...newFavorites[index], online: undefined };
      setFavorites(newFavorites);

      const result = await queryServer(server.ip, server.port);
      if (result.success && result.server) {
        newFavorites[index] = { ...newFavorites[index], ...result.server };
        setFavorites([...newFavorites]);
      }
    }
  };

  if (favorites.length === 0) {
    return (
      <ThemedView style={[styles.container, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
        <EmptyState
          icon="star"
          title="Henüz favori sunucu eklemediniz"
          subtitle="Sunucu sorgula sekmesinden favori ekleyin"
        />
      </ThemedView>
    );
  }

  return (
    <ThemedView style={[styles.container, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
      <FlatList
        data={favorites}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <ServerInfoCard
              server={item}
              isFavorite={true}
              onToggleFavorite={() => handleRemove(item.id)}
              onPress={() => navigation.navigate('ServerDetail', { ip: item.ip, port: item.port })}
            />
          </View>
        )}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={theme.primary}
          />
        }
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    padding: Spacing.lg,
  },
  item: {
    marginBottom: Spacing.md,
  },
});
