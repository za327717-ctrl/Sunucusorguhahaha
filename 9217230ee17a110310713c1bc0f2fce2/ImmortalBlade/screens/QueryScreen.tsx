import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TextInput, ActivityIndicator, FlatList, Platform } from 'react-native';
import { ScreenScrollView } from '@/components/ScreenScrollView';
import { ThemedText } from '@/components/ThemedText';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { ServerInfoCard } from '@/components/ServerInfoCard';
import { AdvancedPortScanning } from '@/components/AdvancedPortScanning';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import { queryServer, scanPorts } from '@/utils/minecraftApi';
import { storage } from '@/utils/storage';
import type { MinecraftServer } from '@/types/minecraft';
import * as Haptics from 'expo-haptics';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { QueryStackParamList } from '@/navigation/QueryStackNavigator';

type Props = NativeStackScreenProps<QueryStackParamList, 'Query'>;

export default function QueryScreen({ navigation }: Props) {
  const { theme } = useTheme();
  const [ip, setIp] = useState('');
  const [port, setPort] = useState('25565');
  const [loading, setLoading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<MinecraftServer | null>(null);
  const [recent, setRecent] = useState<MinecraftServer[]>([]);
  const [isFavorite, setIsFavorite] = useState(false);
  const [defaultPort, setDefaultPort] = useState(25565);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (result) {
      checkFavorite();
    }
  }, [result]);

  const loadData = async () => {
    const recentServers = await storage.getRecent();
    setRecent(recentServers);
    const settings = await storage.getSettings();
    setDefaultPort(settings.defaultPort);
    setPort(settings.defaultPort.toString());
  };

  const checkFavorite = async () => {
    if (result) {
      const favorite = await storage.isFavorite(result.ip, result.port);
      setIsFavorite(favorite);
    }
  };

  const handleQuery = async () => {
    if (!ip.trim()) {
      return;
    }

    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    const portNum = parseInt(port) || defaultPort;
    const queryResult = await queryServer(ip.trim(), portNum);

    if (queryResult.success && queryResult.server) {
      setResult(queryResult.server);
      await storage.addRecent(queryResult.server);
      await loadData();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }

    setLoading(false);
  };

  const handlePortScan = async (startPort?: number, endPort?: number) => {
    if (!ip.trim()) {
      return;
    }

    setScanning(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    const results = await scanPorts(ip.trim(), startPort, endPort);
    
    if (results.length > 0 && results[0].server) {
      setResult(results[0].server);
      setPort(results[0].server.port.toString());
      await storage.addRecent(results[0].server);
      await loadData();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    }

    setScanning(false);
  };

  const handleToggleFavorite = async () => {
    if (!result) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    if (isFavorite) {
      await storage.removeFavorite(`${result.ip}:${result.port}`);
    } else {
      await storage.saveFavorite(result);
    }
    
    setIsFavorite(!isFavorite);
  };

  const handleRecentPress = async (server: MinecraftServer) => {
    setIp(server.ip);
    setPort(server.port.toString());
    
    setLoading(true);
    const queryResult = await queryServer(server.ip, server.port);
    
    if (queryResult.success && queryResult.server) {
      setResult(queryResult.server);
      await storage.addRecent(queryResult.server);
      await loadData();
    }
    
    setLoading(false);
  };

  return (
    <ScreenScrollView>
      <Card>
        <ThemedText style={styles.cardTitle}>Sunucu Bilgileri</ThemedText>
        
        <View style={styles.inputContainer}>
          <ThemedText style={styles.label}>IP Adresi</ThemedText>
          <TextInput
            style={[styles.input, { 
              backgroundColor: theme.inputBackground, 
              borderColor: theme.inputBorder,
              color: theme.text 
            }]}
            value={ip}
            onChangeText={setIp}
            placeholder="örnek: play.hypixel.net"
            placeholderTextColor={theme.textSecondary}
            autoCapitalize="none"
            autoCorrect={false}
          />
        </View>

        <View style={styles.inputContainer}>
          <ThemedText style={styles.label}>Port</ThemedText>
          <TextInput
            style={[styles.input, { 
              backgroundColor: theme.inputBackground, 
              borderColor: theme.inputBorder,
              color: theme.text,
              fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace'
            }]}
            value={port}
            onChangeText={setPort}
            placeholder="25565"
            placeholderTextColor={theme.textSecondary}
            keyboardType="number-pad"
          />
        </View>

        <Button 
          onPress={handleQuery} 
          disabled={loading || scanning || !ip.trim()}
          style={[styles.button, { backgroundColor: theme.primary }]}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <ThemedText style={{ color: '#fff', fontWeight: '600' }}>
              Sorgula
            </ThemedText>
          )}
        </Button>

        <Button 
          onPress={() => handlePortScan()}
          disabled={loading || scanning || !ip.trim()}
          style={[styles.scanButton, { 
            backgroundColor: 'transparent',
            borderWidth: 1,
            borderColor: theme.textSecondary 
          }]}
        >
          {scanning ? (
            <ActivityIndicator color={theme.text} />
          ) : (
            <ThemedText style={{ fontWeight: '600' }}>
              Port Tara
            </ThemedText>
          )}
        </Button>
      </Card>

      <Card>
        <AdvancedPortScanning 
          onScan={handlePortScan}
          isScanning={scanning}
        />
      </Card>

      {result && (
        <View style={styles.resultSection}>
          <ServerInfoCard
            server={result}
            isFavorite={isFavorite}
            onToggleFavorite={handleToggleFavorite}
            onPress={() => navigation.navigate('ServerDetail', { ip: result.ip, port: result.port })}
          />
        </View>
      )}

      {recent.length > 0 && (
        <View style={styles.recentSection}>
          <ThemedText style={styles.sectionTitle}>Son Sorgulanan</ThemedText>
          {recent.map((server, index) => (
            <View key={`${server.ip}:${server.port}-${index}`} style={styles.recentItem}>
              <ServerInfoCard
                server={server}
                onPress={() => navigation.navigate('ServerDetail', { ip: server.ip, port: server.port })}
              />
            </View>
          ))}
        </View>
      )}
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: Spacing.lg,
  },
  inputContainer: {
    marginBottom: Spacing.lg,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: Spacing.sm,
    opacity: 0.8,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.md,
    fontSize: 16,
  },
  button: {
    marginTop: Spacing.sm,
    height: 48,
  },
  scanButton: {
    marginTop: Spacing.md,
    height: 40,
  },
  resultSection: {
    marginTop: Spacing.xl,
  },
  recentSection: {
    marginTop: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: Spacing.md,
  },
  recentItem: {
    marginBottom: Spacing.md,
  },
});
