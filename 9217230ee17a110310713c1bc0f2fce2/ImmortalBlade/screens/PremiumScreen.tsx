import React, { useState } from 'react';
import { View, StyleSheet, TextInput, Alert, Pressable } from 'react-native';
import { ScreenScrollView } from '@/components/ScreenScrollView';
import { ThemedText } from '@/components/ThemedText';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { premiumService } from '@/utils/premium';

const PACKAGES = [
  {
    id: '1month',
    name: '1 Aylık Premium',
    price: '₺29,99',
    ibanPrice: '29.99',
    features: ['Sınırsız sunucu sorgusu', 'Öncelikli destek', 'Reklam yok'],
  },
  {
    id: '3months',
    name: '3 Aylık Premium',
    price: '₺74,99',
    ibanPrice: '74.99',
    features: ['Tüm 1 Aylık özellikleri', '%20 tasarruf', 'Özel rozet'],
    popular: true,
  },
  {
    id: '1year',
    name: 'Yıllık Premium',
    price: '₺199,99',
    ibanPrice: '199.99',
    features: ['Tüm özellikleri', '%33 tasarruf', 'VIP rozetler', 'Özel bölüm'],
  },
];

export default function PremiumScreen() {
  const { theme } = useTheme();
  const [loading, setLoading] = useState(false);

  const handlePurchase = async (packageId: string) => {
    const pkg = PACKAGES.find(p => p.id === packageId);
    if (!pkg) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    Alert.alert(
      'Satın Alma',
      `${pkg.name}\n${pkg.price}\n\nSatın almak istiyor musunuz?`,
      [
        { text: 'İptal', onPress: () => {} },
        {
          text: 'Satın Al',
          onPress: async () => {
            setLoading(true);
            try {
              await new Promise((resolve) => setTimeout(resolve, 2000));
              const purchaseId = `purchase_${Date.now()}_${packageId}`;
              await premiumService.setPremium(purchaseId);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              Alert.alert(
                'Başarılı!',
                `${pkg.name} satın aldınız!\n\nÖdeme: ${pkg.ibanPrice} TL\nHesap: TR500006701000000076747829\n\nPremium özelliklerine erişebilirsiniz.`
              );
            } catch (error) {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
              Alert.alert('Hata', 'Satın alma başarısız oldu.');
            } finally {
              setLoading(false);
            }
          }
        }
      ]
    );
  };

  return (
    <ScreenScrollView>
      <Card>
        <View style={styles.header}>
          <Feather name="gift" size={48} color={theme.primary} />
          <ThemedText style={styles.title}>Premium Üyelik</ThemedText>
          <ThemedText style={styles.subtitle}>Tüm özellikleri kilidi aç</ThemedText>
        </View>
      </Card>

      {PACKAGES.map((pkg) => (
        <Card
          key={pkg.id}
          style={[
            styles.packageCard,
            pkg.popular && { borderColor: theme.primary, borderWidth: 2 },
          ]}
        >
          {pkg.popular && (
            <View style={[styles.popularBadge, { backgroundColor: theme.primary }]}>
              <ThemedText style={styles.popularText}>Popüler</ThemedText>
            </View>
          )}

          <ThemedText style={styles.packageName}>{pkg.name}</ThemedText>
          <ThemedText style={styles.price}>{pkg.price}</ThemedText>

          <View style={styles.features}>
            {pkg.features.map((feature, idx) => (
              <View key={idx} style={styles.featureRow}>
                <Feather name="check" size={16} color={theme.primary} />
                <ThemedText style={styles.featureText}>{feature}</ThemedText>
              </View>
            ))}
          </View>

          <Button
            onPress={() => handlePurchase(pkg.id)}
            loading={loading}
            style={styles.buyButton}
          >
            Satın Al
          </Button>
        </Card>
      ))}

      <Card style={styles.infoCard}>
        <ThemedText style={styles.infoTitle}>Premium Avantajları</ThemedText>
        <ThemedText style={styles.infoText}>
          • Sınırsız sunucu sorgusu{'\n'}
          • Oyuncu listesi indir{'\n'}
          • Reklamsız deneyim{'\n'}
          • Öncelikli destek{'\n'}
          • Özel rozet ve unvanlar
        </ThemedText>
      </Card>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: Spacing.md,
  },
  subtitle: {
    fontSize: 14,
    marginTop: Spacing.sm,
    opacity: 0.7,
  },
  packageCard: {
    marginBottom: Spacing.md,
  },
  popularBadge: {
    position: 'absolute',
    top: Spacing.sm,
    right: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
  },
  popularText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#fff',
  },
  packageName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: Spacing.sm,
  },
  price: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: Spacing.md,
  },
  features: {
    marginBottom: Spacing.lg,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  featureText: {
    marginLeft: Spacing.sm,
    fontSize: 14,
  },
  buyButton: {
    marginTop: Spacing.md,
  },
  infoCard: {
    marginTop: Spacing.lg,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: Spacing.sm,
  },
  infoText: {
    fontSize: 14,
    lineHeight: 22,
  },
});
