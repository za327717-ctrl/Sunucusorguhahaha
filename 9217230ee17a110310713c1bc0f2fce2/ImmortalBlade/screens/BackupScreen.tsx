import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, Alert, Pressable } from 'react-native';
import { ScreenScrollView } from '@/components/ScreenScrollView';
import { ThemedText } from '@/components/ThemedText';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import { Feather } from '@expo/vector-icons';
import { storage } from '@/utils/storage';
import * as Haptics from 'expo-haptics';

export default function BackupScreen() {
  const { theme } = useTheme();
  const [backups, setBackups] = useState<Array<{
    name: string;
    date: number;
    size: number;
    type: 'apk' | 'world' | 'plugin';
  }>>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadBackups();
  }, []);

  const loadBackups = async () => {
    const data = await storage.getBackups();
    setBackups(data.sort((a, b) => b.date - a.date));
  };

  const handleCreateBackup = async () => {
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const backupName = `backup_${new Date().toISOString().split('T')[0]}`;
      await storage.addBackup({
        name: backupName,
        date: Date.now(),
        size: Math.floor(Math.random() * 500) + 50,
        type: 'apk',
      });
      await loadBackups();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Başarılı', 'Yedek oluşturuldu');
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Hata', 'Yedek oluşturulamadı');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteBackup = (backupName: string) => {
    Alert.alert(
      'Yedekleri Sil',
      `${backupName} silinecek, emin misiniz?`,
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Sil',
          style: 'destructive',
          onPress: async () => {
            try {
              await storage.removeBackup(backupName);
              await loadBackups();
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            } catch (error) {
              Alert.alert('Hata', 'Yedek silemedi');
            }
          },
        },
      ]
    );
  };

  const getBackupIcon = (type: string) => {
    switch (type) {
      case 'apk':
        return 'package';
      case 'world':
        return 'globe';
      case 'plugin':
        return 'layers';
      default:
        return 'hard-drive';
    }
  };

  const getBackupTypeLabel = (type: string) => {
    switch (type) {
      case 'apk':
        return 'APK Yedek';
      case 'world':
        return 'Dünya Yedek';
      case 'plugin':
        return 'Eklenti Yedek';
      default:
        return 'Yedek';
    }
  };

  const renderBackup = ({ item }: { item: any }) => (
    <Card elevation={2} style={{ marginBottom: Spacing.md }}>
      <View style={styles.backupItem}>
        <View style={[styles.iconContainer, { backgroundColor: theme.primary + '20' }]}>
          <Feather name={getBackupIcon(item.type) as any} size={24} color={theme.primary} />
        </View>

        <View style={styles.backupInfo}>
          <ThemedText style={styles.backupName}>{item.name}</ThemedText>
          <ThemedText style={styles.backupType}>{getBackupTypeLabel(item.type)}</ThemedText>
          <View style={styles.backupDetails}>
            <Feather name="calendar" size={12} color={theme.textSecondary} />
            <ThemedText style={styles.backupDate}>
              {new Date(item.date).toLocaleDateString('tr-TR')}
            </ThemedText>
            <Feather name="hard-drive" size={12} color={theme.textSecondary} style={{ marginLeft: Spacing.md }} />
            <ThemedText style={styles.backupSize}>{item.size} MB</ThemedText>
          </View>
        </View>

        <Button
          onPress={() => handleDeleteBackup(item.name)}
          style={{
            backgroundColor: '#D9534F',
            paddingHorizontal: Spacing.sm,
          }}
        >
          <Feather name="trash-2" size={16} color="#fff" />
        </Button>
      </View>
    </Card>
  );

  return (
    <ScreenScrollView>
      {/* Header */}
      <Card elevation={2} style={{ marginBottom: Spacing.lg }}>
        <View style={styles.headerContent}>
          <Feather name="hard-drive" size={32} color={theme.primary} />
          <ThemedText style={styles.title}>Yedeklemeler</ThemedText>
          <ThemedText style={styles.subtitle}>
            Sunucu verilerinizi yedekleyip geri yükleyin
          </ThemedText>
        </View>
      </Card>

      {/* Create Backup */}
      <Button
        onPress={handleCreateBackup}
        disabled={loading}
        style={{ backgroundColor: theme.primary, marginBottom: Spacing.xl }}
      >
        <View style={styles.buttonContent}>
          <Feather name="plus" size={18} color="#fff" />
          <ThemedText style={{ color: '#fff', fontWeight: '600', marginLeft: Spacing.sm }}>
            Yeni Yedek Oluştur
          </ThemedText>
        </View>
      </Button>

      {/* Backups List */}
      {backups.length > 0 ? (
        <FlatList
          data={backups}
          renderItem={renderBackup}
          keyExtractor={(item) => item.name}
          scrollEnabled={false}
          ListFooterComponent={<View style={{ height: Spacing.xl }} />}
        />
      ) : (
        <Card elevation={2}>
          <View style={styles.emptyState}>
            <Feather name="inbox" size={48} color={theme.textSecondary} />
            <ThemedText style={styles.emptyText}>Henüz yedek yok</ThemedText>
            <ThemedText style={styles.emptySubtext}>
              İlk yedeklerinizi oluşturmak için yukarıdaki butonu tıklayın
            </ThemedText>
          </View>
        </Card>
      )}
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  headerContent: {
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginTop: Spacing.md,
    marginBottom: Spacing.sm,
  },
  subtitle: {
    fontSize: 14,
    opacity: 0.7,
    textAlign: 'center',
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backupItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.sm,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backupInfo: {
    flex: 1,
  },
  backupName: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: Spacing.xs,
  },
  backupType: {
    fontSize: 12,
    opacity: 0.6,
    marginBottom: Spacing.xs,
  },
  backupDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  backupDate: {
    fontSize: 11,
    opacity: 0.6,
  },
  backupSize: {
    fontSize: 11,
    opacity: 0.6,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.xl * 2,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: Spacing.md,
  },
  emptySubtext: {
    fontSize: 12,
    opacity: 0.6,
    marginTop: Spacing.sm,
    textAlign: 'center',
  },
});
