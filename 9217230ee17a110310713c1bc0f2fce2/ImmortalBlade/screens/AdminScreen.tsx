import React, { useState } from 'react';
import { View, StyleSheet, TextInput, Alert } from 'react-native';
import { ScreenKeyboardAwareScrollView } from '@/components/ScreenKeyboardAwareScrollView';
import { ThemedText } from '@/components/ThemedText';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { premiumService } from '@/utils/premium';

export default function AdminScreen() {
  const { theme } = useTheme();
  const [adminKey, setAdminKey] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [testKey, setTestKey] = useState('');

  const handleUnlock = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    
    const isValid = await premiumService.verifyAdminKey(adminKey);
    if (isValid) {
      setIsUnlocked(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Başarılı', 'Admin paneli açıldı');
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Hata', 'Geçersiz admin anahtarı');
    }
  };

  const handleAddTestPremium = async () => {
    if (!isUnlocked) {
      Alert.alert('Hata', 'Admin paneli kilitli');
      return;
    }

    try {
      const purchaseId = `admin_test_${Date.now()}`;
      await premiumService.setPremium(purchaseId);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Başarılı', 'Test premium aktivasyonu eklendi');
    } catch (error) {
      Alert.alert('Hata', 'Aktif başarısız oldu');
    }
  };

  const handleClearPremium = async () => {
    if (!isUnlocked) {
      Alert.alert('Hata', 'Admin paneli kilitli');
      return;
    }

    Alert.alert('Sil', 'Tüm premium verileri silinecek mi?', [
      { text: 'İptal' },
      {
        text: 'Sil',
        onPress: async () => {
          try {
            await premiumService.clearPremium();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            Alert.alert('Başarılı', 'Premium verisi silindi');
          } catch (error) {
            Alert.alert('Hata', 'Silme başarısız oldu');
          }
        }
      }
    ]);
  };

  return (
    <ScreenKeyboardAwareScrollView>
      <Card>
        <View style={styles.header}>
          <Feather name="shield" size={48} color={theme.primary} />
          <ThemedText style={styles.title}>Admin Paneli</ThemedText>
        </View>
      </Card>

      {!isUnlocked ? (
        <Card>
          <ThemedText style={styles.label}>Admin Anahtarı</ThemedText>
          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: theme.inputBackground,
                borderColor: theme.inputBorder,
                color: theme.text,
              },
            ]}
            placeholder="Admin anahtarını girin"
            placeholderTextColor={theme.textSecondary}
            secureTextEntry
            value={adminKey}
            onChangeText={setAdminKey}
          />
          <Button onPress={handleUnlock} style={styles.button}>
            Açma Kodu Gir
          </Button>
        </Card>
      ) : (
        <>
          <Card>
            <ThemedText style={styles.successText}>✓ Admin Paneli Aktif</ThemedText>
          </Card>

          <Card>
            <ThemedText style={styles.label}>Premium Yönetimi</ThemedText>
            
            <Button 
              onPress={handleAddTestPremium}
              style={styles.button}
            >
              Test Premium Ekle
            </Button>

            <Button 
              onPress={handleClearPremium}
              style={[styles.button, { backgroundColor: '#D9534F' }]}
            >
              Premium Sil
            </Button>
          </Card>

          <Card>
            <ThemedText style={styles.label}>Sistem Bilgileri</ThemedText>
            <ThemedText style={styles.infoText}>
              Ödeme IBAN: TR500006701000000076747829
            </ThemedText>
            <ThemedText style={styles.infoText}>
              Admin Key: Gizli (1 Aylık: ₺29.99)
            </ThemedText>
          </Card>
        </>
      )}
    </ScreenKeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: Spacing.md,
  },
  label: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: Spacing.sm,
  },
  input: {
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    marginBottom: Spacing.md,
    fontSize: 14,
  },
  button: {
    marginBottom: Spacing.md,
  },
  successText: {
    color: '#5CB85C',
    fontSize: 16,
    fontWeight: 'bold',
  },
  infoText: {
    fontSize: 13,
    marginBottom: Spacing.sm,
    opacity: 0.8,
  },
});
