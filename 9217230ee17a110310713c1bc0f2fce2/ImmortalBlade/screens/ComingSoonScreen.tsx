import React, { useState } from 'react';
import { View, StyleSheet, FlatList, Pressable } from 'react-native';
import { ScreenScrollView } from '@/components/ScreenScrollView';
import { ThemedText } from '@/components/ThemedText';
import { Card } from '@/components/Card';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import { Feather } from '@expo/vector-icons';

interface ComingSoonFeature {
  id: string;
  title: string;
  description: string;
  eta: string;
  icon: string;
  category: string;
}

const FEATURES: ComingSoonFeature[] = [
  {
    id: 'server-files',
    title: 'Sunucu Dosyaları',
    description: 'Sunucu yapılandırma dosyalarını, world verilerini ve ayarlarını indirin ve yönetin. Backup ve restore özelliğine de sahip olacak.',
    eta: '2 haftada',
    icon: 'folder',
    category: 'Yönetim',
  },
  {
    id: 'server-console',
    title: 'Sunucu Konsolu',
    description: 'Gerçek zamanlı sunucu konsoluna erişin. Komutları gönderin ve çıktıyı izleyin.',
    eta: '3 haftada',
    icon: 'terminal',
    category: 'Kontrol',
  },
  {
    id: 'player-management',
    title: 'Oyuncu Yönetimi',
    description: 'Oyuncu izinlerini, inventorysini ve statistiğini yönetin. Ban ve mute listesini kontrol edin.',
    eta: '3 haftada',
    icon: 'users',
    category: 'Yönetim',
  },
  {
    id: 'performance-monitor',
    title: 'Performans İzleme',
    description: 'Sunucu performansını TPS, bellek kullanımı ve oyuncu gecikme süresini grafikleriyle izleyin.',
    eta: '4 haftada',
    icon: 'activity',
    category: 'Analiz',
  },
  {
    id: 'plugin-manager',
    title: 'Eklenti Yöneticisi',
    description: 'Yüklü eklentileri, sürümlerini ve ayarlarını görüntüleyin. Sıcak yükleme ve kaldırma desteği.',
    eta: '4 haftada',
    icon: 'package',
    category: 'Kontrol',
  },
  {
    id: 'world-editor',
    title: 'Dünya Düzenleyici',
    description: 'Harita verilerini işleyin ve özelleştirin. Seed ve biome düzenlemesi mümkün olacak.',
    eta: '5 haftada',
    icon: 'map',
    category: 'Geliştirme',
  },
  {
    id: 'backup-schedule',
    title: 'Otomatik Yedekleme',
    description: 'Sunucunuzu planlı şekilde otomatik olarak yedekleyin. Bulut depolama desteği eklenecek.',
    eta: '2 haftada',
    icon: 'hard-drive',
    category: 'Güvenlik',
  },
  {
    id: 'api-tools',
    title: 'API Araçları',
    description: 'Özel otomasyon ve entegrasyon için REST API\'ya erişim. Webhook desteği de gelecek.',
    eta: '6 haftada',
    icon: 'code',
    category: 'Geliştirme',
  },
];

export default function ComingSoonScreen() {
  const { theme } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = Array.from(new Set(FEATURES.map((f) => f.category)));

  const filteredFeatures = selectedCategory
    ? FEATURES.filter((f) => f.category === selectedCategory)
    : FEATURES;

  const renderFeature = ({ item }: { item: ComingSoonFeature }) => (
    <Card style={{ marginBottom: Spacing.md }}>
      <View style={styles.featureContent}>
        <View style={styles.featureLeft}>
          <View
            style={[
              styles.iconContainer,
              { backgroundColor: theme.primary + '20' },
            ]}
          >
            <Feather
              name={item.icon as any}
              size={24}
              color={theme.primary}
            />
          </View>
        </View>

        <View style={styles.featureMiddle}>
          <ThemedText style={styles.featureTitle}>{item.title}</ThemedText>
          <ThemedText style={styles.featureDescription}>
            {item.description}
          </ThemedText>
          <View style={styles.etaContainer}>
            <Feather name="clock" size={12} color={theme.textSecondary} />
            <ThemedText style={styles.etaText}>{item.eta}</ThemedText>
          </View>
        </View>
      </View>
    </Card>
  );

  return (
    <ScreenScrollView>
      {/* Header */}
      <Card style={{ marginBottom: Spacing.lg }}>
        <View style={styles.headerContent}>
          <Feather name="zap" size={32} color={theme.primary} />
          <ThemedText style={styles.headerTitle}>Yakında Gelecek</ThemedText>
          <ThemedText style={styles.headerSubtitle}>
            Sunucu yönetiminin geleceği şu özellikleri getiriyor
          </ThemedText>
        </View>
      </Card>

      {/* Category Filter */}
      <Card>
        <ThemedText style={styles.categoryTitle}>Kategoriye Göre Filtrele</ThemedText>
        <View style={styles.categoryContainer}>
          <Pressable
            onPress={() => setSelectedCategory(null)}
            style={[
              styles.categoryButton,
              {
                backgroundColor:
                  selectedCategory === null ? theme.primary : theme.backgroundDefault,
                borderColor:
                  selectedCategory === null ? theme.primary : theme.border,
              },
            ]}
          >
            <ThemedText
              style={[
                styles.categoryButtonText,
                {
                  color: selectedCategory === null ? '#fff' : theme.text,
                  fontWeight: selectedCategory === null ? '600' : '500',
                },
              ]}
            >
              Tümü ({FEATURES.length})
            </ThemedText>
          </Pressable>

          {categories.map((cat) => {
            const count = FEATURES.filter((f) => f.category === cat).length;
            return (
              <Pressable
                key={cat}
                onPress={() => setSelectedCategory(cat)}
                style={[
                  styles.categoryButton,
                  {
                    backgroundColor:
                      selectedCategory === cat
                        ? theme.primary
                        : theme.backgroundDefault,
                    borderColor:
                      selectedCategory === cat ? theme.primary : theme.border,
                  },
                ]}
              >
                <ThemedText
                  style={[
                    styles.categoryButtonText,
                    {
                      color:
                        selectedCategory === cat ? '#fff' : theme.text,
                      fontWeight:
                        selectedCategory === cat ? '600' : '500',
                    },
                  ]}
                >
                  {cat} ({count})
                </ThemedText>
              </Pressable>
            );
          })}
        </View>
      </Card>

      {/* Features List */}
      <View style={{ marginBottom: Spacing.xl }}>
        <FlatList
          data={filteredFeatures}
          renderItem={renderFeature}
          keyExtractor={(item) => item.id}
          scrollEnabled={false}
        />
      </View>

      {/* Info Card */}
      <Card>
        <View style={styles.infoContent}>
          <Feather name="info" size={20} color={theme.primary} />
          <ThemedText style={styles.infoText}>
            Bu tarihler tahmini olup, değişebilir. Önceki haberler için profil
            sayfasını kontrol edin.
          </ThemedText>
        </View>
      </Card>
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  headerContent: {
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    marginTop: Spacing.md,
    marginBottom: Spacing.sm,
  },
  headerSubtitle: {
    fontSize: 14,
    opacity: 0.7,
    textAlign: 'center',
  },
  categoryTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: Spacing.md,
  },
  categoryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  categoryButton: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.xs,
    borderWidth: 1,
  },
  categoryButtonText: {
    fontSize: 12,
  },
  featureContent: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  featureLeft: {
    justifyContent: 'flex-start',
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.sm,
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureMiddle: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: Spacing.xs,
  },
  featureDescription: {
    fontSize: 12,
    opacity: 0.7,
    lineHeight: 18,
    marginBottom: Spacing.sm,
  },
  etaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  etaText: {
    fontSize: 11,
    opacity: 0.6,
    fontStyle: 'italic',
  },
  infoContent: {
    flexDirection: 'row',
    gap: Spacing.md,
    alignItems: 'flex-start',
  },
  infoText: {
    flex: 1,
    fontSize: 12,
    opacity: 0.7,
    lineHeight: 18,
  },
});
