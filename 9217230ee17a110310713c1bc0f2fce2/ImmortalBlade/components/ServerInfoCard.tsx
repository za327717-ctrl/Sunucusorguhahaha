import React from 'react';
import { View, StyleSheet, Image, Pressable, Share, Platform } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { Card } from '@/components/Card';
import { StatusBadge } from '@/components/StatusBadge';
import { PingIndicator } from '@/components/PingIndicator';
import { Feather } from '@expo/vector-icons';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import type { MinecraftServer } from '@/types/minecraft';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';

interface ServerInfoCardProps {
  server: MinecraftServer;
  isFavorite?: boolean;
  onToggleFavorite?: () => void;
  onPress?: () => void;
}

export function ServerInfoCard({ server, isFavorite, onToggleFavorite, onPress }: ServerInfoCardProps) {
  const { theme } = useTheme();

  const handleCopy = async () => {
    await Clipboard.setStringAsync(`${server.ip}:${server.port}`);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Minecraft Sunucu: ${server.ip}:${server.port}\n${server.online ? `Oyuncular: ${server.players?.online}/${server.players?.max}` : 'Çevrimdışı'}`,
      });
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  const CardWrapper = onPress ? Pressable : View;

  return (
    <CardWrapper onPress={onPress} style={{ opacity: onPress ? 1 : 1 }}>
      <Card>
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Image
              source={
                server.icon
                  ? { uri: server.icon }
                  : require('@/assets/images/grass-block.png')
              }
              style={styles.icon}
            />
            <View style={styles.headerInfo}>
              <ThemedText style={styles.serverName} numberOfLines={1}>
                {server.motd || server.ip}
              </ThemedText>
              <ThemedText style={[styles.serverAddress, { fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' }]}>
                {server.ip}:{server.port}
              </ThemedText>
            </View>
          </View>
        </View>

        <View style={styles.statusRow}>
          <StatusBadge online={server.online} />
          {server.online && server.ping !== undefined && (
            <PingIndicator ping={server.ping} />
          )}
        </View>

        {server.online && (
          <View style={styles.details}>
            <View style={styles.detailItem}>
              <Feather name="users" size={16} color={theme.textSecondary} />
              <ThemedText style={styles.detailText}>
                {server.players?.online}/{server.players?.max} oyuncu
              </ThemedText>
            </View>
            {server.version && (
              <View style={styles.detailItem}>
                <Feather name="package" size={16} color={theme.textSecondary} />
                <ThemedText style={styles.detailText}>{server.version}</ThemedText>
              </View>
            )}
          </View>
        )}

        <View style={styles.actions}>
          {onToggleFavorite && (
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                onToggleFavorite();
              }}
              style={({ pressed }) => [
                styles.actionButton,
                { opacity: pressed ? 0.6 : 1 },
              ]}
            >
              <Feather
                name={isFavorite ? 'star' : 'star'}
                size={20}
                color={isFavorite ? theme.warning : theme.textSecondary}
                style={{ fontWeight: isFavorite ? 'bold' : 'normal' }}
              />
            </Pressable>
          )}
          <Pressable
            onPress={handleShare}
            style={({ pressed }) => [
              styles.actionButton,
              { opacity: pressed ? 0.6 : 1 },
            ]}
          >
            <Feather name="share-2" size={20} color={theme.textSecondary} />
          </Pressable>
          <Pressable
            onPress={handleCopy}
            style={({ pressed }) => [
              styles.actionButton,
              { opacity: pressed ? 0.6 : 1 },
            ]}
          >
            <Feather name="copy" size={20} color={theme.textSecondary} />
          </Pressable>
        </View>
      </Card>
    </CardWrapper>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.md,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  icon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.xs,
    marginRight: Spacing.md,
  },
  headerInfo: {
    flex: 1,
  },
  serverName: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: Spacing.xs / 2,
  },
  serverAddress: {
    fontSize: 12,
    opacity: 0.6,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  details: {
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  detailText: {
    fontSize: 14,
    opacity: 0.8,
  },
  actions: {
    flexDirection: 'row',
    gap: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(128, 128, 128, 0.2)',
  },
  actionButton: {
    padding: Spacing.sm,
  },
});
