import React from 'react';
import { View, StyleSheet } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { Feather } from '@expo/vector-icons';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';

interface StatusBadgeProps {
  online: boolean;
}

export function StatusBadge({ online }: StatusBadgeProps) {
  const { theme } = useTheme();

  return (
    <View
      style={[
        styles.badge,
        { backgroundColor: online ? theme.success + '20' : theme.danger + '20' },
      ]}
    >
      <Feather
        name={online ? 'check-circle' : 'x-circle'}
        size={14}
        color={online ? theme.success : theme.danger}
      />
      <ThemedText
        style={[
          styles.text,
          { color: online ? theme.success : theme.danger },
        ]}
      >
        {online ? 'Çevrimiçi' : 'Çevrimdışı'}
      </ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  text: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: Spacing.xs,
    textTransform: 'uppercase',
  },
});
