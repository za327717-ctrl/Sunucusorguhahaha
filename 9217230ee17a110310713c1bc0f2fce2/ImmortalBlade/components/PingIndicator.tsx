import React from 'react';
import { View, StyleSheet } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { Feather } from '@expo/vector-icons';
import { Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';

interface PingIndicatorProps {
  ping: number;
}

export function PingIndicator({ ping }: PingIndicatorProps) {
  const { theme } = useTheme();

  const getColor = () => {
    if (ping < 50) return theme.success;
    if (ping < 100) return theme.warning;
    return theme.danger;
  };

  return (
    <View style={styles.container}>
      <Feather name="activity" size={14} color={getColor()} />
      <ThemedText style={[styles.text, { color: getColor() }]}>
        {ping}ms
      </ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  text: {
    fontSize: 14,
    fontWeight: '600',
  },
});
