import React, { useState } from 'react';
import { View, StyleSheet, Pressable, ActivityIndicator } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { Button } from '@/components/Button';
import { Spacing, BorderRadius } from '@/constants/theme';
import { useTheme } from '@/hooks/useTheme';
import { Feather } from '@expo/vector-icons';

interface AdvancedPortScanningProps {
  onScan: (startPort: number, endPort: number) => void;
  isScanning?: boolean;
}

export function AdvancedPortScanning({ onScan, isScanning }: AdvancedPortScanningProps) {
  const { theme } = useTheme();
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [startPort, setStartPort] = useState('25565');
  const [endPort, setEndPort] = useState('25569');

  const handleQuickScan = () => {
    onScan(25565, 25569);
  };

  const handleCustomScan = () => {
    const start = parseInt(startPort) || 25565;
    const end = parseInt(endPort) || 25569;
    if (start <= end && start > 0 && end <= 65535) {
      onScan(start, end);
      setShowAdvanced(false);
    }
  };

  return (
    <View>
      <Pressable
        onPress={() => setShowAdvanced(!showAdvanced)}
        style={[styles.header, { borderBottomColor: theme.border }]}
      >
        <View style={styles.headerContent}>
          <Feather name="settings" size={18} color={theme.primary} />
          <ThemedText style={styles.headerText}>Gelişmiş Port Taraması</ThemedText>
        </View>
        <Feather name={showAdvanced ? 'chevron-up' : 'chevron-down'} size={18} color={theme.textSecondary} />
      </Pressable>

      {showAdvanced && (
        <View style={styles.content}>
          <View style={styles.portRangeContainer}>
            <View style={styles.portInput}>
              <ThemedText style={styles.portLabel}>Başlangıç</ThemedText>
              <ThemedText
                style={[
                  styles.portValue,
                  { backgroundColor: theme.inputBackground, color: theme.text },
                ]}
              >
                {startPort}
              </ThemedText>
            </View>
            <ThemedText style={styles.divider}>→</ThemedText>
            <View style={styles.portInput}>
              <ThemedText style={styles.portLabel}>Bitiş</ThemedText>
              <ThemedText
                style={[
                  styles.portValue,
                  { backgroundColor: theme.inputBackground, color: theme.text },
                ]}
              >
                {endPort}
              </ThemedText>
            </View>
          </View>

          <View style={styles.presetContainer}>
            <ThemedText style={styles.presetLabel}>Ön Ayarlar:</ThemedText>
            <View style={styles.presetButtons}>
              {[
                { label: 'Standart', start: 25565, end: 25569 },
                { label: 'Geniş', start: 25560, end: 25575 },
                { label: 'Tüm', start: 20000, end: 30000 },
              ].map((preset) => (
                <Pressable
                  key={preset.label}
                  onPress={() => {
                    setStartPort(preset.start.toString());
                    setEndPort(preset.end.toString());
                  }}
                  style={[
                    styles.presetButton,
                    {
                      backgroundColor: theme.backgroundDefault,
                      borderColor: theme.border,
                    },
                  ]}
                >
                  <ThemedText style={styles.presetText}>{preset.label}</ThemedText>
                </Pressable>
              ))}
            </View>
          </View>

          <Button
            onPress={handleCustomScan}
            disabled={isScanning}
            style={{ backgroundColor: theme.primary, marginTop: Spacing.lg }}
          >
            {isScanning ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <ThemedText style={{ color: '#fff', fontWeight: '600' }}>
                Özel Aralıkta Tara
              </ThemedText>
            )}
          </Button>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    borderBottomWidth: 1,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  headerText: {
    fontSize: 14,
    fontWeight: '600',
  },
  content: {
    padding: Spacing.md,
  },
  portRangeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginBottom: Spacing.lg,
  },
  portInput: {
    alignItems: 'center',
  },
  portLabel: {
    fontSize: 12,
    opacity: 0.6,
    marginBottom: Spacing.xs,
  },
  portValue: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.xs,
    fontWeight: '600',
    fontSize: 14,
  },
  divider: {
    fontSize: 16,
    fontWeight: '600',
    opacity: 0.4,
  },
  presetContainer: {
    marginBottom: Spacing.lg,
  },
  presetLabel: {
    fontSize: 12,
    fontWeight: '600',
    opacity: 0.6,
    marginBottom: Spacing.sm,
  },
  presetButtons: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  presetButton: {
    flex: 1,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    borderRadius: BorderRadius.xs,
    borderWidth: 1,
    alignItems: 'center',
  },
  presetText: {
    fontSize: 12,
    fontWeight: '600',
  },
});
