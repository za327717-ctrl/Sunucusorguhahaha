# Minecraft Sunucu Sorgulayıcı - Design Guidelines

## Architecture Decisions

### Authentication
**No authentication required** - This is a single-user utility app with local data storage.

**Profile/Settings Screen Required:**
- User-customizable avatar: Generate 1 Minecraft-themed avatar (simple blocky character silhouette)
- Display name field (default: "Oyuncu")
- App preferences:
  - Dark/Light theme toggle
  - Default port (25565)
  - Scan timeout duration (5s, 10s, 15s)
  - Language (Türkçe as default)

### Navigation
**Tab Navigation (3 tabs):**
1. **Sorgula** (Query) - Main query interface
2. **Favoriler** (Favorites) - Saved servers list
3. **Profil** (Profile) - Settings and profile

### Screen Specifications

#### 1. Sorgula (Query Screen)
**Purpose:** Primary interface for querying Minecraft servers

**Layout:**
- **Header:** Transparent, custom navigation header
  - Title: "Sunucu Sorgula"
  - Right button: Info icon (shows app tutorial)
- **Main content:** Scrollable root view
  - Safe area insets: top (headerHeight + Spacing.xl), bottom (tabBarHeight + Spacing.xl)

**Components:**
- **Server Input Card** (elevated card with shadow):
  - IP address text input with placeholder "sunucu-ip.com"
  - Port text input with placeholder "25565" (numeric keyboard)
  - Large primary button "Sorgula" (gradient background)
  - Small text button "Port Tara" below (scans common ports 25565-25570)
  
- **Status Indicator** (when query active):
  - Animated circular progress with pulse effect
  - Status text "Sorgulanıyor..." / "Port taranıyor..."

- **Server Info Card** (shown after successful query):
  - Online/Offline badge (green/red pill badge)
  - Ping latency display (ms) with color coding: <50ms green, 50-100ms yellow, >100ms red
  - Server icon (64x64 if available, fallback to Minecraft grass block icon)
  - Server name/MOTD (support Minecraft color codes)
  - Player count: "12/100 oyuncu"
  - Version tag
  - Action buttons row:
    - Star icon (add to favorites)
    - Share icon (share server details)
    - Copy icon (copy IP)

- **Recent Servers Section** (below, max 5):
  - List of recently queried servers
  - Each item: compact version of server info card
  - Swipe-to-delete gesture

#### 2. Favoriler (Favorites Screen)
**Purpose:** Quick access to saved servers

**Layout:**
- **Header:** Transparent, custom navigation header
  - Title: "Favori Sunucular"
  - Right button: Edit mode toggle (trash icon)
- **Main content:** FlatList
  - Safe area insets: top (headerHeight + Spacing.xl), bottom (tabBarHeight + Spacing.xl)

**Components:**
- **Empty State** (when no favorites):
  - Centered icon (star outline)
  - Text: "Henüz favori sunucu eklemediniz"
  - Secondary text: "Sunucu sorgula sekmesinden favori ekleyin"
  
- **Favorite Server Cards:**
  - Same design as query result cards
  - Tap to re-query and show fresh status
  - Long-press to show action menu (remove from favorites, edit nickname)
  - Drag handles in edit mode for reordering

#### 3. Profil (Profile Screen)
**Purpose:** User settings and app preferences

**Layout:**
- **Header:** Transparent, custom navigation header
  - Title: "Profil"
- **Main content:** Scrollable form
  - Safe area insets: top (headerHeight + Spacing.xl), bottom (tabBarHeight + Spacing.xl)

**Components:**
- **Profile Section:**
  - Large circular avatar (120x120) - tappable to change
  - Text input for display name
  
- **Preferences Section** (grouped form):
  - Theme toggle (Dark/Light/System)
  - Default port number input
  - Scan timeout slider (5-30 seconds)
  
- **About Section:**
  - App version
  - Tutorial button
  - Rate app (opens store)

## Design System

### Color Palette
**Primary Colors (Minecraft-inspired):**
- Primary: `#5CB85C` (Minecraft green - for online status, success)
- Secondary: `#5BC0DE` (Light blue - for accents)
- Danger: `#D9534F` (Red - for offline status, errors)
- Warning: `#F0AD4E` (Orange/amber - for medium ping)

**Neutral Colors:**
- Background (Light): `#F5F5F5`
- Background (Dark): `#1A1A1A`
- Surface (Light): `#FFFFFF`
- Surface (Dark): `#2D2D2D`
- Text Primary (Light): `#212121`
- Text Primary (Dark): `#FFFFFF`
- Text Secondary (Light): `#757575`
- Text Secondary (Dark): `#B0B0B0`

### Typography
- **Headings:** System bold, 24px (screen titles), 18px (card headers)
- **Body:** System regular, 16px
- **Captions:** System regular, 14px
- **Labels:** System medium, 14px
- **Monospace (for IPs/ports):** System monospace, 14px

### Spacing
- xs: 4px
- sm: 8px
- md: 12px
- lg: 16px
- xl: 24px
- xxl: 32px

### Visual Design
- **Cards:** Border radius 12px, elevation with shadow (shadowOffset: {width: 0, height: 2}, shadowOpacity: 0.10, shadowRadius: 4)
- **Buttons:** 
  - Primary: Gradient background (#5CB85C to #4A9D4A), border radius 8px, min height 48px
  - Secondary: Transparent with border, border radius 8px
  - Icon buttons: 44x44 touch target, no background
- **Input Fields:** Border radius 8px, border width 1px, height 48px, padding 12px
- **Badges:** Pill shape (border radius 999px), padding 4px 12px, uppercase text
- **Status Indicators:** Use Feather icons (check-circle, x-circle, activity for loading)

### Interaction Design
- **Touch Feedback:** All touchable elements scale to 0.95 on press
- **Loading States:** Animated pulse or spinner (Feather: loader icon rotating)
- **Error States:** Red border on input fields, inline error text below
- **Success States:** Green checkmark animation, brief success message
- **Pull-to-Refresh:** On favorites list to re-query all servers
- **Haptic Feedback:** Light haptic on button press, medium on successful query, heavy on error

### Assets Required
1. **Minecraft Grass Block Icon** (64x64) - default server icon fallback
2. **User Avatar** (1 preset): Simple blocky Minecraft-style character silhouette with #5CB85C accent color
3. **Empty State Illustration:** Minimal star outline icon

### Accessibility
- Minimum touch target size: 44x44px
- Color contrast ratio minimum 4.5:1 for text
- Support for system font scaling
- Screen reader labels for all interactive elements (Turkish language)
- Keyboard navigation support for text inputs
- Error messages in clear Turkish language